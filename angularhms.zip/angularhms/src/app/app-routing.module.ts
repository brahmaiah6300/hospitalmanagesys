import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreatePatientComponent } from './create-patient/create-patient.component';
import { CreatePhysicianComponent } from './create-physician/create-physician.component';
import { SearchPhysicianComponent } from './search-physician/search-physician.component';
import { SearchPhysicianStateComponent } from './search-physician-state/search-physician-state.component';
import { SearchPhysicianPlanComponent } from './search-physician-plan/search-physician-plan.component';
import { SearchPhysicianDeptComponent } from './search-physician-dept/search-physician-dept.component';
import { CreateDiagnosisComponent } from './create-diagnosis/create-diagnosis.component';
import { PatientHistoryComponent } from './patient-history/patient-history.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { AuthguardService } from './authguard.service';
import { AboutComponent } from './about/about.component';

const routes: Routes = [
  { path: 'login' , component: LoginComponent },
  { path: 'addpat', component: CreatePatientComponent},
  { path: 'addphy', component: CreatePhysicianComponent},
  { path: 'search', component: SearchPhysicianComponent },
  { path: 'findbystate', component: SearchPhysicianStateComponent },
 { path: 'findbyplan', component: SearchPhysicianPlanComponent },
 { path: 'findbydept', component: SearchPhysicianDeptComponent },
 { path: 'adddiagnosis', component: CreateDiagnosisComponent},
{ path: 'patienthistory', component: PatientHistoryComponent, canActivate:[AuthguardService]},
 { path: 'logout',component: LogoutComponent, canActivate:[AuthguardService]},
 { path: 'about', component: AboutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
