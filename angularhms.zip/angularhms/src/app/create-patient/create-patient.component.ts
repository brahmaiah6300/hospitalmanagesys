import { Component, OnInit } from '@angular/core';
import { Patient } from '../patient';
import { PatientService } from '../patient.service';

@Component({
  selector: 'app-create-patient',
  templateUrl: './create-patient.component.html',
  styleUrls: ['./create-patient.component.css']
})
export class CreatePatientComponent implements OnInit {

  patient: Patient = new Patient();
  submitted = false;

  constructor(private patientService: PatientService) { }

  ngOnInit(): void {
  }

  newPatient():void {
    this.submitted = false;
    this.patient = new Patient();
  }

  onSubmit(){
    this.save();
  }

  save() {
  
   this.patientService.createPatient(this.patient)
    .subscribe(
      data => {
        console.log(data);
        this.submitted = true;
      },
      error => console.log(error));
     this.patient = new Patient();
  }

}
