import { Component, OnInit } from '@angular/core';
import { PhysicianService } from '../physician.service';
import { Physician } from '../physician';

@Component({
  selector: 'app-search-physician',
  templateUrl: './search-physician.component.html',
  styleUrls: ['./search-physician.component.css']
})
export class SearchPhysicianComponent implements OnInit {
 

  constructor(private physicianService : PhysicianService) { }

  

  ngOnInit() {
   
  }

 
}
