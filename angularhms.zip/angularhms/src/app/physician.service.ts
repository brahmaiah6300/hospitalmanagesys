import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PhysicianService {
  
  private baseUrl = 'http://localhost:8080/api/physicians';
  constructor(private http: HttpClient) { }

  createPhysician(physician:any): Observable<any> {
    return this.http.post(this.baseUrl, physician);
  }

  getPhysiciansByDept(dept: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/dept/${dept}`);
  }
  
  getPhysiciansByInsuranceplan(insuranceplan: any): Observable<any> {
    return this.http.get(`${this.baseUrl}/insuranceplan/${insuranceplan}`);
  }

  getPhysiciansByState(state: any): Observable<any> {
    return this.http.get(`${this.baseUrl}/state/${state}`);
  }


  getPhysicians(): Observable<any> {
    return this.http.get(this.baseUrl);
  }
}
