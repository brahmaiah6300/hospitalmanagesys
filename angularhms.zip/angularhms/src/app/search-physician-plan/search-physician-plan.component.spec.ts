import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchPhysicianPlanComponent } from './search-physician-plan.component';

describe('SearchPhysicianPlanComponent', () => {
  let component: SearchPhysicianPlanComponent;
  let fixture: ComponentFixture<SearchPhysicianPlanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchPhysicianPlanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchPhysicianPlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
