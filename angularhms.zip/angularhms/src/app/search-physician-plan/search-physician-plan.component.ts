import { Component, OnInit } from '@angular/core';
import { Physician } from '../physician';
import { PhysicianService } from '../physician.service';

@Component({
  selector: 'app-search-physician-plan',
  templateUrl: './search-physician-plan.component.html',
  styleUrls: ['./search-physician-plan.component.css']
})
export class SearchPhysicianPlanComponent implements OnInit {

  
  insuranceplan: any;
  

  physicians : Physician[];

  constructor(private physicianService : PhysicianService) { }

  p: Number = 1;
  count: Number = 3;
  
  ngOnInit() {
    
    this.insuranceplan = null;
    
  }

 
  submitted= false;
  private searchPhysicians1(){
    this.physicians = [];
    this.physicianService.getPhysiciansByInsuranceplan(this.insuranceplan).subscribe(
      data => {
        this.physicians = data;
        this.submitted = true;}
      ,
    );
  }

 
 

  onSubmit1(){
    this.searchPhysicians1();
  }

 
}
