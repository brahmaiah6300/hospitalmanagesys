export class Patient {
    id: number;
    firstname: string;
    lastname: string;
    password: string;
    dob: Date;
    email: string;
    phno: number;
    state : string;
    insuranceplan: string;
}