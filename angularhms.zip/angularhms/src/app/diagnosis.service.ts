import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Diagnosis } from './diagnosis';
import { Observable } from 'rxjs';
import { PatientService } from './patient.service';

@Injectable({
  providedIn: 'root'
})
export class DiagnosisService {
  
  private baseUrl = 'http://localhost:8080/api/diagnosis';
  constructor(private http: HttpClient) { }
  
  createDiagnosis(diagnosis: Diagnosis,value: number,name: string): Observable<any>{
    return this.http.post(`${this.baseUrl}/${value}/${name}`, diagnosis);
  }
  
 
}
