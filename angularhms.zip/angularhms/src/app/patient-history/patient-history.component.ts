import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Patient } from '../patient';
import { PatientService } from '../patient.service';
import { DiagnosisHistory } from '../diagnosishistory';


@Component({
  selector: 'app-patient-history',
  templateUrl: './patient-history.component.html',
  styleUrls: ['./patient-history.component.css']
})
export class PatientHistoryComponent implements OnInit {
 
  patients : Observable<Patient>;
 // diagnosishistory : DiagnosisHistory[];
//diagnosishistory: DiagnosisHistory = new DiagnosisHistory();
 diagnosishistory: Observable<DiagnosisHistory>;
  constructor(private patientService: PatientService) { }

  ngOnInit(): void {
    this.reloadData();
  }
  topicHasError = true;
  patientid: number
    validatePatient(value) {
      console.log(value)
      if (value === 'default') {
        this.topicHasError = true;
      } else {
        this.topicHasError = false;
      }
    }

    // private getPatientHistory(){
    //   this.diagnosishistory = [];
    //   this.patientService.getPatientById(this.patientid).subscribe(
    //     data => {
    //       this.diagnosishistory = data;
    //     }
    //   )
    // }
    onSubmit(){
      console.log("component"+this.patientid)
     // this.getPatientHistory();
      this.diagnosishistory = this.patientService.getPatientById(this.patientid);
     
    }

    reloadData(){
      this.patients = this.patientService.getPatients();
    }
}
