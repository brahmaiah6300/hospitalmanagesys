import { Component, OnInit } from '@angular/core';
import { Physician } from '../physician';
import { PhysicianService } from '../physician.service';

@Component({
  selector: 'app-search-physician-dept',
  templateUrl: './search-physician-dept.component.html',
  styleUrls: ['./search-physician-dept.component.css']
})
export class SearchPhysicianDeptComponent implements OnInit {
 
  dept : any;

  physicians : Physician[];

  constructor(private physicianService : PhysicianService) { }

  p: Number = 1;
  count: Number = 3;
  
  ngOnInit() {
   
    this.dept = null;
  }

  submitted= false;
  private searchPhysicians2(){
    this.physicians = [];
    this.physicianService.getPhysiciansByDept(this.dept).subscribe(
      data => {
        this.physicians = data;
        this.submitted = true;}
      ,
    );
  }
 

  onSubmit2(){
    this.searchPhysicians2();
  }

}
