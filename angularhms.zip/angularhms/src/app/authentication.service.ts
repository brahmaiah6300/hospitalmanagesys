import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  uname : string;
  username:string;
  password:string;
  constructor() { }

  authenticate(username,password){
    //database logic
    // this.username = name;
    // this.pass = password;
    // return this.userService.CreateLogin(name);
    if(username === "admin" && password === "password"){
      sessionStorage.setItem('username', username)
      return true;
    } else {
      return false;
    }
  }

  isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    this.uname=user;
    return !(user === null)
  }

  logOut() {
    sessionStorage.removeItem('username')
  }
}
