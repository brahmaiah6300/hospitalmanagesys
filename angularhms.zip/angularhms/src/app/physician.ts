export class Physician {
    id: any;
    firstname: string;
    lastname : string;
    dept : any;
    qualification: string;
    experience: any;
    state : string;
    insuranceplan: any;
}