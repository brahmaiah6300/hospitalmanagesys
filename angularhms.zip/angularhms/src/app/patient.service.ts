import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PatientService {

  public patientdata  = [];
  private baseUrl = 'http://localhost:8080/api/patients';
  constructor(private http: HttpClient) { }

  createPatient(patient:any): Observable<any> {
    return this.http.post(this.baseUrl, patient);
  }

  getPatients(): Observable<any> {
    return this.http.get(this.baseUrl);
  }

  getPatientById(id: number): Observable<any>{
    //return this.http.get("http://localhost:8080/diagnosis/"+id).subscribe((data)=>{this.patientdata=[data];});
    return this.http.get(`${this.baseUrl}/${id}`);
  }
 
}
