import { Patient } from './patient';

export class DiagnosisHistory{

    id: number;
    billamount:any;
    dateofdiagnosis:Date;
    followup: string;
    dateoffollowup:Date;
    physicianname:string;
    symptoms:string;
    patient: Patient;
    
    
}