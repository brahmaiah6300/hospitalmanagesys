import { Patient } from './patient';

export class Diagnosis {
    id:number;
    patientid: number;
    symptoms:string;
    diagnosisprovided:string;
    physicianname: string;
    dateofdiagnosis:Date;
    followup:string;
    dateoffollowup:Date;
    billamount:any;
    cardnumber:any;
    modeofpayment:string;
    
}
