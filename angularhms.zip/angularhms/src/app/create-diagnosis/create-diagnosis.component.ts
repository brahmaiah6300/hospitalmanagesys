import { Component, OnInit } from '@angular/core';
import { Diagnosis } from '../diagnosis';
import { DiagnosisService } from '../diagnosis.service';
import { PatientService } from '../patient.service';
import { Observable } from 'rxjs';
import { Patient } from '../patient';
import { Physician } from '../physician';
import { PhysicianService } from '../physician.service';

@Component({
  selector: 'app-create-diagnosis',
  templateUrl: './create-diagnosis.component.html',
  styleUrls: ['./create-diagnosis.component.css']
})
export class CreateDiagnosisComponent implements OnInit {

  patients : Observable<Patient[]>;
  physicians: Observable<Physician[]>;
  diagnosis: Diagnosis = new Diagnosis();
  submitted = false;

  constructor(private diagnosisService: DiagnosisService,private patientService: PatientService,private physicianService: PhysicianService) { }

  ngOnInit(): void {
    this.reloadData();
  }

  topicHasError = true;
  patientid: number
    validatePatient(value) {
      console.log(value)
      if (value === 'default') {
        this.topicHasError = true;
      } else {
        this.topicHasError = false;
      }
    }

    topicHasError1 = true;
    physicianname: string;
      validatePhysician(value) {
        console.log(value)
        if (value === 'default') {
          this.topicHasError1 = true;
        } else {
          this.topicHasError1 = false;
        }
      }


    reloadData(){
      this.patients = this.patientService.getPatients();
      this.physicians = this.physicianService.getPhysicians();
    }
  newDiagnosis():void {
    this.submitted = false;
    this.diagnosis = new Diagnosis();
  }

  onSubmit(){
    console.log(this.patientid);
    this.save(this.patientid,this.physicianname);
  }

  save(value,name) {
  
    
   this.diagnosisService.createDiagnosis(this.diagnosis,value,name)
    .subscribe(
      data => {
        console.log(data);
        this.submitted = true;
      },
      error => console.log(error));
     this.diagnosis = new Diagnosis();
  }

}
