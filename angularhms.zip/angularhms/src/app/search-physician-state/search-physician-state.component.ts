import { Component, OnInit } from '@angular/core';
import { PhysicianService } from '../physician.service';
import { Physician } from '../physician';

@Component({
  selector: 'app-search-physician-state',
  templateUrl: './search-physician-state.component.html',
  styleUrls: ['./search-physician-state.component.css']
})
export class SearchPhysicianStateComponent implements OnInit {

  state: any;

  physicians : Physician[];
  constructor(private physicianService : PhysicianService) { }

  p: Number = 1;
  count: Number = 3;
  
  ngOnInit() {
    this.state = null;
    
  }

  submitted= false;
  private searchPhysicians(){
    this.physicians = [];
    this.physicianService.getPhysiciansByState(this.state).subscribe(
      data => {
        this.physicians = data;
        this.submitted = true;}
      ,
    );
  }

  
  onSubmit(){
    this.searchPhysicians();
  }

}
