import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchPhysicianStateComponent } from './search-physician-state.component';

describe('SearchPhysicianStateComponent', () => {
  let component: SearchPhysicianStateComponent;
  let fixture: ComponentFixture<SearchPhysicianStateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchPhysicianStateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchPhysicianStateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
