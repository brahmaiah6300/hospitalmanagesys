import { Component, OnInit } from '@angular/core';
import { Physician } from '../physician';
import { PhysicianService } from '../physician.service';

@Component({
  selector: 'app-create-physician',
  templateUrl: './create-physician.component.html',
  styleUrls: ['./create-physician.component.css']
})
export class CreatePhysicianComponent implements OnInit {

  physician: Physician = new Physician();
  submitted = false;

  constructor(private physicianService: PhysicianService) { }

  ngOnInit(): void {
  }

  newPhysician():void {
    this.submitted = false;
    this.physician = new Physician();
  }

  onSubmit(){
    this.save();
  }

  save() {
    this.physicianService.createPhysician(this.physician)
    .subscribe(
      data => {
        console.log(data);
        this.submitted = true;
      },
      error => console.log(error));
    
    this.physician = new Physician();
  }

}
