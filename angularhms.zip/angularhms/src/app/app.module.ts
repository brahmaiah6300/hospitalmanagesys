import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { CreatePatientComponent } from './create-patient/create-patient.component';
import { CreatePhysicianComponent } from './create-physician/create-physician.component';
import { SearchPhysicianComponent } from './search-physician/search-physician.component';
import { SearchPhysicianPlanComponent } from './search-physician-plan/search-physician-plan.component';
import { SearchPhysicianDeptComponent } from './search-physician-dept/search-physician-dept.component';
import { SearchPhysicianStateComponent } from './search-physician-state/search-physician-state.component';
import { CreateDiagnosisComponent } from './create-diagnosis/create-diagnosis.component';

import { PatientHistoryComponent } from './patient-history/patient-history.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { AboutComponent } from './about/about.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    CreatePatientComponent,
    CreatePhysicianComponent,
    SearchPhysicianComponent,
    SearchPhysicianPlanComponent,
    SearchPhysicianDeptComponent,
    SearchPhysicianStateComponent,
    CreateDiagnosisComponent,
    PatientHistoryComponent,
    LoginComponent,
    LogoutComponent,
    AboutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
