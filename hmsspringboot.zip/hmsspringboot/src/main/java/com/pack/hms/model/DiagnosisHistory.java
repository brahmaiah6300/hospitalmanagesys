package com.pack.hms.model;

import java.util.Date;


public class DiagnosisHistory {

	private int diagnosisId;
	
	private long billamount;
	
	private Date dateofdiagnosis;
	
	private Date dateoffollowup;
	
	private String physicianname;
	
	private String symptoms;
	
	
	private long patientid;
	
	private String firstname,lastname;
	
	

	public int getDiagnosisId() {
		return diagnosisId;
	}

	public void setDiagnosisId(int diagnosisId) {
		this.diagnosisId = diagnosisId;
	}

	public long getBillamount() {
		return billamount;
	}

	public void setBillamount(long billamount) {
		this.billamount = billamount;
	}

	public Date getDateofdiagnosis() {
		return dateofdiagnosis;
	}

	public void setDateofdiagnosis(Date dateofdiagnosis) {
		this.dateofdiagnosis = dateofdiagnosis;
	}

	public Date getDateoffollowup() {
		return dateoffollowup;
	}

	public void setDateoffollowup(Date dateoffollowup) {
		this.dateoffollowup = dateoffollowup;
	}

	public String getPhysicianname() {
		return physicianname;
	}

	public void setPhysicianname(String physicianname) {
		this.physicianname = physicianname;
	}

	public String getSymptoms() {
		return symptoms;
	}

	public void setSymptoms(String symptoms) {
		this.symptoms = symptoms;
	}

	public long getPatientid() {
		return patientid;
	}

	public void setPatientid(long patientid) {
		this.patientid = patientid;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}



	
}
