package com.pack.hms.model;

import java.util.Date;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;





@Entity
@Table(name= "patient")
public class Patient {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	private String firstname;
	private String lastname;
	private String password;
	private Date dob;
	private String email;
	private long phno;
	private String state;
	private String insuranceplan;
	
	  @JsonIgnore
	  @OneToOne(mappedBy="patient")
	   private Diagnosis diagnosis;
//	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "patient")
//	private Diagnosis diagnosis;
	
	public Patient() {
		
	}

	
	


	public Patient(long id, String firstname, String lastname, String password, Date dob, String email, long phno,
			String state, String insuranceplan) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.password = password;
		this.dob = dob;
		this.email = email;
		this.phno = phno;
		this.state = state;
		this.insuranceplan = insuranceplan;
	}





	public Patient(String firstname, String lastname, String password, Date dob, String email, long phno, String state,
			String insuranceplan) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.password = password;
		this.dob = dob;
		this.email = email;
		this.phno = phno;
		this.state = state;
		this.insuranceplan = insuranceplan;
	}





	public long getId() {
		return id;
	}





	public void setId(long id) {
		this.id = id;
	}





	public String getFirstname() {
		return firstname;
	}





	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}





	public String getLastname() {
		return lastname;
	}





	public void setLastname(String lastname) {
		this.lastname = lastname;
	}





	public String getPassword() {
		return password;
	}





	public void setPassword(String password) {
		this.password = password;
	}





	public Date getDob() {
		return dob;
	}





	public void setDob(Date dob) {
		this.dob = dob;
	}





	public String getEmail() {
		return email;
	}





	public void setEmail(String email) {
		this.email = email;
	}





	public long getPhno() {
		return phno;
	}





	public void setPhno(long phno) {
		this.phno = phno;
	}





	public String getState() {
		return state;
	}





	public void setState(String state) {
		this.state = state;
	}





	public String getInsuranceplan() {
		return insuranceplan;
	}





	public void setInsuranceplan(String insuranceplan) {
		this.insuranceplan = insuranceplan;
	}





	public Diagnosis getDiagnosis() {
		return diagnosis;
	}





	public void setDiagnosis(Diagnosis diagnosis) {
		this.diagnosis = diagnosis;
	}





	@Override
	public String toString() {
		return "Patient [id=" + id + ", firstname=" + firstname + ", lastname=" + lastname + ", password=" + password
				+ ", dob=" + dob + ", email=" + email + ", phno=" + phno + ", state=" + state + ", insuranceplan="
				+ insuranceplan + ", diagnosis=" + diagnosis + "]";
	}
	
	
	
	
	
}
