package com.pack.hms.model;

import java.util.Date;

import javax.persistence.*;





@Entity
@Table(name  = "diagnosis")
public class Diagnosis {

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int diagnosisId;
	
	   @OneToOne
	    @JoinColumn(name="patientid")
	    private Patient patient;
	 
	//private Integer patientid;
	
	private String symptoms;
	
	private String physicianname;
	
	private String diagnosisprovided;
	
	private Date dateofdiagnosis;
	
	private String followup;
	
	private Date dateoffollowup;
	
	private Double billamount;
	
	private String cardnumber;
	
	private String modeofpayment;

	
	public int getDiagnosisId() {
		return diagnosisId;
	}

	public void setDiagnosisId(int diagnosisId) {
		this.diagnosisId = diagnosisId;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public String getSymptoms() {
		return symptoms;
	}

	public void setSymptoms(String symptoms) {
		this.symptoms = symptoms;
	}

	public String getPhysicianname() {
		return physicianname;
	}

	public void setPhysicianname(String physicianname) {
		this.physicianname = physicianname;
	}

	public String getDiagnosisprovided() {
		return diagnosisprovided;
	}

	public void setDiagnosisprovided(String diagnosisprovided) {
		this.diagnosisprovided = diagnosisprovided;
	}

	public Date getDateofdiagnosis() {
		return dateofdiagnosis;
	}

	public void setDateofdiagnosis(Date dateofdiagnosis) {
		this.dateofdiagnosis = dateofdiagnosis;
	}

	public String getFollowup() {
		return followup;
	}

	public void setFollowup(String followup) {
		this.followup = followup;
	}

	public Date getDateoffollowup() {
		return dateoffollowup;
	}

	public void setDateoffollowup(Date dateoffollowup) {
		this.dateoffollowup = dateoffollowup;
	}

	public Double getBillamount() {
		return billamount;
	}

	public void setBillamount(Double billamount) {
		this.billamount = billamount;
	}

	public String getCardnumber() {
		return cardnumber;
	}

	public void setCardnumber(String cardnumber) {
		this.cardnumber = cardnumber;
	}

	public String getModeofpayment() {
		return modeofpayment;
	}

	public void setModeofpayment(String modeofpayment) {
		this.modeofpayment = modeofpayment;
	}

	@Override
	public String toString() {
		return "Diagnosis [diagnosisId=" + diagnosisId + ", patient=" + patient + ", symptoms=" + symptoms
				+ ", physicianname=" + physicianname + ", diagnosisprovided=" + diagnosisprovided + ", dateofdiagnosis="
				+ dateofdiagnosis + ", followup=" + followup + ", dateoffollowup=" + dateoffollowup + ", billamount="
				+ billamount + ", cardnumber=" + cardnumber + ", modeofpayment=" + modeofpayment + "]";
	}

	
	 
	
	

	
	
}
