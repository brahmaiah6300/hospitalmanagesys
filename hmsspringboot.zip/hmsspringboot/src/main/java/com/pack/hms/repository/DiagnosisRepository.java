package com.pack.hms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.pack.hms.model.Diagnosis;
import com.pack.hms.model.DiagnosisHistory;


public interface DiagnosisRepository extends CrudRepository<Diagnosis, Long> {

//	@Query(value = " select d.diagnosis_id,d.billamount,d.dateofdiagnosis,d.dateoffollowup,d.physicianname,d.symptoms,p.firstname,p.lastname from diagnosis d,patient p where d.patientid = ?1", nativeQuery = true)
//	List<DiagnosisHistory> findHistory(long id);

	// Optional<DiagnosisHistory> findHistory(long id);
	// List<DiagnosisHistory> findHistory(long id);
   @Query(value = " select d.diagnosis_id,d.billamount,d.dateofdiagnosis,d.dateoffollowup,d.physicianname,d.symptoms,d.cardnumber,d.followup,d.diagnosisprovided,d.patientid,d.modeofpayment,p.firstname,p.lastname from diagnosis d,patient p where d.patientid = ?1", nativeQuery = true)
	List<Diagnosis> listDiagnosis(long id); 
}
