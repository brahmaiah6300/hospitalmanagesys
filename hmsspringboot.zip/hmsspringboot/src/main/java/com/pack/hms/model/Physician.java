package com.pack.hms.model;

import javax.persistence.*;

@Entity
@Table(name= "physician")
public class Physician {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String firstname;
	private String lastname;
	private String dept;
	private String qualification;
	private Integer experience;
	private String state;
	private String insuranceplan;
	
	public Physician() {
		
	}

	public Physician(String firstname, String lastname, String dept, String qualification, Integer experience,
			String state, String insuranceplan) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.dept = dept;
		this.qualification = qualification;
		this.experience = experience;
		this.state = state;
		this.insuranceplan = insuranceplan;
	}

	public Physician(long id, String firstname, String lastname, String dept, String qualification, Integer experience,
			String state, String insuranceplan) {
		super();
		this.id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.dept = dept;
		this.qualification = qualification;
		this.experience = experience;
		this.state = state;
		this.insuranceplan = insuranceplan;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public Integer getExperience() {
		return experience;
	}

	public void setExperience(Integer experience) {
		this.experience = experience;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getInsuranceplan() {
		return insuranceplan;
	}

	public void setInsuranceplan(String insuranceplan) {
		this.insuranceplan = insuranceplan;
	}
	
	
	
	
}
