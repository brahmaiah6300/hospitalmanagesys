package com.pack.hms.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pack.hms.model.Diagnosis;
import com.pack.hms.model.DiagnosisHistory;
import com.pack.hms.model.Patient;
import com.pack.hms.model.Physician;
import com.pack.hms.repository.DiagnosisRepository;
import com.pack.hms.repository.PatientRepository;
import com.pack.hms.repository.PhysicianRepository;
import com.sun.istack.logging.Logger;

@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
@RestController
public class AdminController {

	private Logger log = Logger.getLogger(AdminController.class);
	@Autowired
	PatientRepository repository;

	@Autowired
	PhysicianRepository repositoryphy;

	@Autowired
	DiagnosisRepository repositorydia;

	@PostMapping(value = "/patients")
	public ResponseEntity<Patient> postPatient(@RequestBody Patient patient) {
		try {
			log.info("Inside Post Patient");

			Patient _patient = repository.save(
					new Patient(patient.getFirstname(), patient.getLastname(), patient.getPassword(), patient.getDob(),
							patient.getEmail(), patient.getPhno(), patient.getState(), patient.getInsuranceplan()));
			log.info("Going to Server giving response");
			return new ResponseEntity<>(_patient, HttpStatus.CREATED);
		} catch (Exception e) {
			log.warning("Exception is there");
			return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
		}
	}

	@PostMapping(value = "/physicians")
	public ResponseEntity<Physician> postPhysician(@RequestBody Physician physician) {
		try {
			log.info("Inside Post Physician");
			Physician _physician = repositoryphy.save(new Physician(physician.getFirstname(), physician.getLastname(),
					physician.getDept(), physician.getQualification(), physician.getExperience(), physician.getState(),
					physician.getInsuranceplan()));
			log.info("Going to Server giving resposnse");
			return new ResponseEntity<>(_physician, HttpStatus.CREATED);
		} catch (Exception e) {
			log.warning("Exception is there");
			return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
		}
	}

	@GetMapping(value = "physicians/dept/{dept}")
	public ResponseEntity<List<Physician>> findByDept(@PathVariable String dept) {
		try {
			log.info("Inside Get Physician by Department");
			List<Physician> physicians = repositoryphy.findByDept(dept);

			if (physicians.isEmpty()) {
				log.info("Going to Server giving reponse giving No content");
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

			log.info("Going to Server giving reposnse as OK ");
			// System.out.println(physicians.size());
			return new ResponseEntity<>(physicians, HttpStatus.OK);
		} catch (Exception e) {
			log.warning("Exception is there");
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
		}
	}

	@GetMapping(value = "physicians/state/{state}")
	public ResponseEntity<List<Physician>> findByState(@PathVariable String state) {
		try {
			log.info("Inside Get Physician by State");
			List<Physician> physicians = repositoryphy.findByState(state);

			if (physicians.isEmpty()) {

				log.info("Going to Server giving reponse giving No content");

				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			log.info("Going to Server giving reposnse as OK ");
			// System.out.println(physicians.size());
			return new ResponseEntity<>(physicians, HttpStatus.OK);
		} catch (Exception e) {
			log.warning("Exception is there");
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
		}
	}

	@GetMapping(value = "physicians/insuranceplan/{insuranceplan}")
	public ResponseEntity<List<Physician>> findByInsuranceplan(@PathVariable String insuranceplan) {
		try {
			log.info("Inside Get Physician by InsurancePlan");
			List<Physician> physicians = repositoryphy.findByInsuranceplan(insuranceplan);

			if (physicians.isEmpty()) {
				log.info("Going to Server giving reponse giving No content");

				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			log.info("Going to Server giving response as OK ");

			// System.out.println(physicians.size());
			return new ResponseEntity<>(physicians, HttpStatus.OK);
		} catch (Exception e) {
			log.warning("Exception is there");
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
		}
	}

	@PostMapping(value = "/diagnosis/{pid}/{pname}")
	public ResponseEntity<Diagnosis> postDiagnosis(@PathVariable("pid") long pid, @PathVariable("pname") String pname,
			@RequestBody Diagnosis diagnosis) {
		try {
			// System.out.println(" entered data for diagnosis"+diagnosis+ " "+pid);
			log.info("Inside Post Diagnosis");
			Patient pat = repository.findById(pid).get();
			// System.out.println(pat);
			// System.out.println(diagnosis.getSymptoms());
			Diagnosis _diagnosis = new Diagnosis();
			_diagnosis.setSymptoms(diagnosis.getSymptoms());
			_diagnosis.setPhysicianname(pname);
			_diagnosis.setDiagnosisprovided(diagnosis.getDiagnosisprovided());
			_diagnosis.setDateofdiagnosis(diagnosis.getDateoffollowup());
			_diagnosis.setFollowup(diagnosis.getFollowup());
			_diagnosis.setDateoffollowup(diagnosis.getDateoffollowup());
			_diagnosis.setBillamount(diagnosis.getBillamount());
			_diagnosis.setCardnumber(diagnosis.getCardnumber());
			_diagnosis.setModeofpayment(diagnosis.getModeofpayment());
			_diagnosis.setPatient(pat);
			repositorydia.save(_diagnosis);
			log.info("Going to Server giving reposnse as CREATED ");

			return new ResponseEntity<>(_diagnosis, HttpStatus.CREATED);

		} catch (Exception e) {
			log.warning("Exception is there");
			return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
		}
	}

	@GetMapping("/patients")
	public ResponseEntity<List<Patient>> getPatients() {
		List<Patient> patients = new ArrayList<Patient>();
		try {
			log.info("Inside Get All Patients");
			repository.findAll().forEach(patients::add);

			if (patients.isEmpty()) {
				log.info("Going to Server giving reponse giving No content");
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			// System.out.println(patients.size());
			log.info("Going to Server page giving Ok response");
			return new ResponseEntity<>(patients, HttpStatus.OK);
		} catch (Exception e) {
			log.warning("Exception is there");
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/physicians")
	public ResponseEntity<List<Physician>> getPhysicians() {
		List<Physician> physicians = new ArrayList<Physician>();
		try {
			log.info("Inside Get Physician");
			repositoryphy.findAll().forEach(physicians::add);

			if (physicians.isEmpty()) {
				log.info("Going to Server giving reponse giving No content");
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}

			log.info("Going to Server giving reposnse as OK ");
			// System.out.println(physicians.size());
			return new ResponseEntity<>(physicians, HttpStatus.OK);
		} catch (Exception e) {
			log.warning("Exception is there");
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	// Getting output
	@GetMapping("/patients/{id}")
	public ResponseEntity<List<Diagnosis>> getHistory(@PathVariable("id") long id) {

		try {
			log.info("Inside  Get History of patient diagnosis");
			List<Diagnosis> history1 = new ArrayList<Diagnosis>();
			List<Diagnosis> history = new ArrayList<Diagnosis>();
			log.config("ID Count was printed");
			System.out.println(id);
			repositorydia.listDiagnosis(id).forEach(history::add);
			// System.out.println(history);
			history1.add(history.get(1));
			if (history.isEmpty()) {
				log.info("Going to Server giving reponse giving No content");

				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			// System.out.println("hello"+history.size());

			return new ResponseEntity<>(history1, HttpStatus.OK);
		} catch (Exception e) {
			log.warning("Exception is there");
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
