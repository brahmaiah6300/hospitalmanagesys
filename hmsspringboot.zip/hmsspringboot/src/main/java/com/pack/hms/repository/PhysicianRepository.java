package com.pack.hms.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.pack.hms.model.Physician;

public interface PhysicianRepository extends CrudRepository<Physician,Long> {

	List<Physician> findByDept(String dept);

	List<Physician> findByState(String state);

	List<Physician> findByInsuranceplan(String insuranceplan);

	
}
